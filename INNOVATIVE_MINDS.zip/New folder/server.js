const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const csv = require('csv-parser');

const app = express();
const PORT = 3000;

// Set storage for multer
const storage = multer.diskStorage({
    destination: 'uploads/',
    filename: (req, file, cb) => {
        cb(null, 'predictive_maintenance_data.csv');
    }
});
const upload = multer({ storage });

// Serve static files
app.use(express.static('public'));

// Upload CSV endpoint
app.post('/upload', upload.single('file'), (req, res) => {
    const results = [];
    fs.createReadStream(path.join(__dirname, 'uploads', 'predictive_maintenance_data.csv'))
        .pipe(csv())
        .on('data', (data) => results.push(data))
        .on('end', () => {
            res.json({ success: true, data: results });
        });
});

// Start server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
