document.getElementById("sensorForm").addEventListener("submit", function (event) {
    event.preventDefault();

    // Get values from form inputs
    const componentId = document.getElementById("componentId").value;
    const temperature = document.getElementById("temperature").value;
    const pressure = document.getElementById("pressure").value;
    const vibration = document.getElementById("vibration").value;
    const operationalHours = document.getElementById("operationalHours").value;

    // Default values for prediction and damage type
    let failurePrediction = "No failure predicted";
    let damageType = "No damage";
    let damageExplanation = "";
    let solution = "";

    // Predict failure based on conditions
    if (temperature > 100 || pressure > 200) {
        failurePrediction = "Possible failure detected";
        damageType = "Corrosion";
        damageExplanation = "Corrosion occurs when the material is exposed to high temperature or pressure for prolonged periods.";
        solution = "Implement corrosion-resistant materials or regular maintenance checks.";
    } else if (vibration > 10) {
        failurePrediction = "Possible failure detected";
        damageType = "Cracks";
        damageExplanation = "Excessive vibration can lead to cracks forming in the material due to repetitive stress.";
        solution = "Ensure proper vibration damping and alignment during installation.";
    } else if (operationalHours > 1000) {
        failurePrediction = "Possible failure detected";
        damageType = "Wear";
        damageExplanation = "Wear occurs due to prolonged use of the component, resulting in gradual material loss.";
        solution = "Regular lubrication and maintenance can reduce wear.";
    }

    // Populate the table with the data
    document.getElementById("outputComponentId").textContent = componentId;
    document.getElementById("outputTemperature").textContent = temperature;
    document.getElementById("outputPressure").textContent = pressure;
    document.getElementById("outputVibration").textContent = vibration;
    document.getElementById("outputOperationalHours").textContent = operationalHours;
    document.getElementById("outputPrediction").textContent = failurePrediction;
    document.getElementById("outputDamage").textContent = damageType;
    document.getElementById("outputDamageExplanation").textContent = damageExplanation;
    document.getElementById("outputSolution").textContent = solution;

    // Show the result table
    document.getElementById("resultTable").style.display = "table";

    // Reset form inputs after submission
    document.getElementById("sensorForm").reset();
});
